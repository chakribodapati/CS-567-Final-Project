import os
import shutil

class FileManager:
    def __init__(self, working_directory):
        self.working_directory = working_directory
        if not os.path.exists(self.working_directory):
            os.makedirs(self.working_directory)

    def list_files(self):
        files = os.listdir(self.working_directory)
        if not files:
            print("No files found.")
        else:
            for file in files:
                print(file)

    def create_file(self, filename, content=""):
        path = os.path.join(self.working_directory, filename)
        with open(path, 'w') as file:
            file.write(content)
        print(f"{filename} has been created.")

    def read_file(self, filename):
        path = os.path.join(self.working_directory, filename)
        if os.path.exists(path):
            with open(path, 'r') as file:
                print(file.read())
        else:
            print("File does not exist.")

    def update_file(self, filename, content):
        path = os.path.join(self.working_directory, filename)
        if os.path.exists(path):
            with open(path, 'a') as file:
                file.write(content)
            print(f"{filename} has been updated.")
        else:
            print("File does not exist.")

    def delete_file(self, filename):
        path = os.path.join(self.working_directory, filename)
        if os.path.exists(path):
            os.remove(path)
            print(f"{filename} has been deleted.")
        else:
            print("File does not exist.")

    def copy_file(self, filename, new_location):
        src_path = os.path.join(self.working_directory, filename)
        if os.path.exists(src_path):
            shutil.copy(src_path, new_location)
            print(f"{filename} has been copied to {new_location}.")
        else:
            print("File does not exist.")

    def search_file(self, filename):
        for root, dirs, files in os.walk(self.working_directory):
            if filename in files:
                print(f"Found {filename} at {root}")
                return
        print("File not found.")

def main():
    directory = input("Enter the directory path to manage files: ")
    manager = FileManager(directory)

    while True:
        print("\nFile Manager Options:")
        print("1. List Files")
        print("2. Create File")
        print("3. Read File")
        print("4. Update File")
        print("5. Delete File")
        print("6. Copy File")
        print("7. Search File")
        print("8. Exit")
        choice = input("Choose an option: ")
        if choice == '1':
            manager.list_files()
        elif choice == '2':
            filename = input("Enter the filename to create: ")
            content = input("Enter content for the file (optional, press enter to skip): ")
            manager.create_file(filename, content)
        elif choice == '3':
            filename = input("Enter the filename to read: ")
            manager.read_file(filename)
        elif choice == '4':
            filename = input("Enter the filename to update: ")
            content = input("Enter content to append to the file: ")
            manager.update_file(filename, content)
        elif choice == '5':
            filename = input("Enter the filename to delete: ")
            manager.delete_file(filename)
        elif choice == '6':
            filename = input("Enter the filename to copy: ")
            new_location = input("Enter the new location to copy the file to: ")
            manager.copy_file(filename, new_location)
        elif choice == '7':
            filename = input("Enter the filename to search for: ")
            manager.search_file(filename)
        elif choice == '8':
            break
        else:
            print("Invalid option, please try again.")

if __name__ == "__main__":
    main()
