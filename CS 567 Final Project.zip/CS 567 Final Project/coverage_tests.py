import unittest
import coverage

import test_file_manager

cov = coverage.Coverage()
cov.start()

unittest.main(module=test_file_manager)

cov.stop()

cov.save()

cov.report()
