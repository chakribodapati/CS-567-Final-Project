import unittest
import os
import shutil
from file_manager import FileManager


class TestFileManager(unittest.TestCase):

    def setUp(self):
        self.test_dir = "test_directory"
        os.makedirs(self.test_dir)
        self.manager = FileManager(self.test_dir)

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_list_files_empty(self):
        self.assertEqual(self.manager.list_files(), "No files found.")

    def test_create_file(self):
        filename = "test_file.txt"
        content = "This is a test file."
        self.manager.create_file(filename, content)
        self.assertTrue(os.path.exists(os.path.join(self.test_dir, filename)))

    def test_read_file(self):
        filename = "test_file.txt"
        content = "This is a test file."
        self.manager.create_file(filename, content)
        self.assertEqual(self.manager.read_file(filename), content)

    def test_update_file(self):
        filename = "test_file.txt"
        content = "This is a test file."
        self.manager.create_file(filename, content)
        additional_content = "\nAdditional content."
        expected_content = content + additional_content
        self.manager.update_file(filename, additional_content)
        self.assertEqual(self.manager.read_file(filename), expected_content)

    def test_delete_file(self):
        filename = "test_file.txt"
        content = "This is a test file."
        self.manager.create_file(filename, content)
        self.manager.delete_file(filename)
        self.assertFalse(os.path.exists(os.path.join(self.test_dir, filename)))

    def test_copy_file(self):
        filename = "test_file.txt"
        content = "This is a test file."
        self.manager.create_file(filename, content)
        new_location = "test_directory_copy"
        self.manager.copy_file(filename, new_location)
        self.assertTrue(os.path.exists(os.path.join( filename,new_location)))

    def test_search_file(self):
        filename = "test_file.txt"
        content = "This is a test file."
        self.manager.create_file(filename, content)
        self.assertEqual(self.manager.search_file(filename), f"Found {filename} at {self.test_dir}")

if __name__ == '__main__':
    unittest.main()
